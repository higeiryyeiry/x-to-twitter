// Runs in the PAGE's own JS context (world: MAIN) so it can intercept X's favicon code directly.
(() => {
  const ICON = "data:image/x-icon;base64,AAABAAEAEBAAAAEAIABoBAAAFgAAACgAAAAQAAAAIAAAAAEAIAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOGjUjzkplOb6KhU2eyrVPXtrFX77axV4e2rVbDqqlRd56hTBgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANygUS7doVF736JRpuSmU/HqqVT/7axV/+6sVf/urFX/7qxV/+2rVd3qqVRCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADnp1MO7KtUqO2sVf/urFX/7qxV/+6sVf/urFX/7axV/OqpVGIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADkplMc66pUx+6sVf/urFX/7qxV/+6sVf/urFX/7qxV/+6sVf/tq1X856hTPQAAAAAAAAAAAAAAAAAAAAAAAAAA56hTx+2rVf/urFX/7qxV/+6sVf/urFX/7qxV/+6sVf/urFX/7qxV/+uqVN/kpVMJAAAAAAAAAAAAAAAA5KZTBuuqVI/trFX37qxV/+6sVf/urFX/7qxV/+6sVf/urFX/7qxV/+6sVf/tq1X/56dTZwAAAAAAAAAAAAAAAOeoU5ntq1X/7qxV/+6sVf/urFX/7qxV/+6sVf/urFX/7qxV/+6sVf/urFX/7qxV/+mpVM4AAAAAAAAAAN+iURLnp1P97atV/+6sVf/tq1X/7KtU/+qqVP/rqlT/7axV/+6sVf/urFX/7qxV/+6sVf/qqlT+4qRSEQAAAADfolET6KhUdu2rVfnrqlT/56hT/+SmU//ipFL/5KZT/+uqVP/urFX/7qxV/+6sVf/urFX/66pU/+SlUzYAAAAA4aNSBuioVOjpqVT/5KVT/9+iUdLdoVFu3KBRKeCjUi7pqVT/7axV/+6sVf/urFX/7qxV/+2rVf/np1NFAAAAAN+iUSnkpVP/4qRS9N6hUWzcoFEBAAAAAAAAAADeoVEX5KZT/uuqVP/trFX/7axV/+yrVP/qqVT/5aZT5d+iUSzcoFEX3qFR7NygUTAAAAAAAAAAAAAAAAAAAAAAAAAAAN+iUabkplP/56hT/+ioVP/lplP/4qRS/uCjUqneoVExAAAAANufUB0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADcoFEI3aFRi9+iUe3folHx3qFRnNygURXcoFFT3KBRJgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//8AAMD/AADAPwAA8B8AAOAPAADABwAAwAcAAIADAACAAwAAwAMAAIcDAACfAQAAvwEAAP+HAAD//wAA//8AAA==";
  const OUR_ID = "custom-favicon-link";

  const nativeSetAttr = Element.prototype.setAttribute;
  const nativeAppend = Node.prototype.appendChild;
  const nativeInsert = Node.prototype.insertBefore;
  const hrefDesc = Object.getOwnPropertyDescriptor(HTMLLinkElement.prototype, "href");

  function isIconLink(el) {
    return el instanceof HTMLLinkElement && /icon/i.test(el.getAttribute("rel") || "");
  }

  // Force any icon <link> to point at our icon, instead of removing it
  // (removing breaks the site's own bookkeeping and starts a tug-of-war).
  function fix(el) {
    if (!isIconLink(el)) return;
    if (el.getAttribute("href") !== ICON) nativeSetAttr.call(el, "href", ICON);
    if (el.getAttribute("type") !== "image/x-icon") nativeSetAttr.call(el, "type", "image/x-icon");
    if (el.hasAttribute("sizes")) el.removeAttribute("sizes");
    if (el.hasAttribute("media")) el.removeAttribute("media");
  }

  // 1) Intercept attribute writes (how React Helmet sets favicons)
  Element.prototype.setAttribute = function () {
    const r = nativeSetAttr.apply(this, arguments);
    if (this instanceof HTMLLinkElement) fix(this);
    return r;
  };

  // 2) Intercept .href = "..." writes
  if (hrefDesc && hrefDesc.set) {
    Object.defineProperty(HTMLLinkElement.prototype, "href", {
      configurable: true,
      enumerable: true,
      get: hrefDesc.get,
      set(v) {
        hrefDesc.set.call(this, v);
        fix(this);
      },
    });
  }

  // 3) Intercept insertion of icon links
  Node.prototype.appendChild = function (node) {
    fix(node);
    return nativeAppend.call(this, node);
  };
  Node.prototype.insertBefore = function (node, ref) {
    fix(node);
    return nativeInsert.call(this, node, ref);
  };

  // 4) Safety net: observer + periodic sweep
  function sweep() {
    removeGrok();
    fixNav();
    replaceLogo();
    fixTitle();
    document.querySelectorAll('link[rel*="icon"]').forEach(fix);
    if (document.head && !document.getElementById(OUR_ID) && !document.querySelector('link[rel*="icon"]')) {
      const l = document.createElement("link");
      l.id = OUR_ID;
      l.rel = "icon";
      l.type = "image/x-icon";
      l.href = ICON;
      nativeAppend.call(document.head, l);
    }
  }

  new MutationObserver((muts) => {
    for (const m of muts) {
      if (m.type === "attributes") fix(m.target);
      else m.addedNodes.forEach((n) => {
        if (n.nodeType === 1) { fix(n); if (n.querySelectorAll) n.querySelectorAll('link[rel*="icon"]').forEach(fix); }
      });
    }
  }).observe(document, { subtree: true, childList: true, attributes: true, attributeFilter: ["href", "rel"] });


  // ---- Sidebar/header logo swap: X -> Twitter bird ----
  const BIRD_COLOR = "#1DA1F2";
  const BIRD_PATH = "M23.643 4.937c-.835.37-1.732.62-2.675.733.962-.576 1.7-1.49 2.048-2.578-.9.534-1.897.922-2.958 1.13-.85-.904-2.06-1.47-3.4-1.47-2.572 0-4.658 2.086-4.658 4.66 0 .364.042.718.12 1.06-3.873-.195-7.304-2.05-9.602-4.868-.4.69-.63 1.49-.63 2.342 0 1.616.823 3.043 2.072 3.878-.764-.025-1.482-.234-2.11-.583v.06c0 2.257 1.605 4.14 3.737 4.568-.392.106-.803.162-1.227.162-.3 0-.593-.028-.877-.082.593 1.85 2.313 3.198 4.352 3.234-1.595 1.25-3.604 1.995-5.786 1.995-.376 0-.747-.022-1.112-.065 2.062 1.323 4.51 2.093 7.14 2.093 8.57 0 13.255-7.098 13.255-13.254 0-.2-.005-.402-.014-.602.91-.658 1.7-1.477 2.323-2.41z";
  const LOGO_SELECTOR = 'a[href="/home"][aria-label="X"] svg, a[href="/"][aria-label="X"] svg, a[href="/home"][aria-label="Twitter"] svg';

  function replaceLogo() {
    document.querySelectorAll(LOGO_SELECTOR).forEach((svg) => {
      const paths = svg.querySelectorAll("path");
      if (!paths.length) return;
      const p = paths[0];
      if (p.getAttribute("d") !== BIRD_PATH) p.setAttribute("d", BIRD_PATH);
      if (p.style.getPropertyValue("fill") !== BIRD_COLOR) p.style.setProperty("fill", BIRD_COLOR, "important");
      for (let i = 1; i < paths.length; i++) paths[i].style.display = "none";
    });
  }

  let logoQueued = false;
  new MutationObserver(() => {
    if (logoQueued) return;
    logoQueued = true;
    requestAnimationFrame(() => { logoQueued = false; replaceLogo(); });
  }).observe(document, { subtree: true, childList: true });


  // ---- Tab title rewrite: "... / X" -> "... / Twitter" ----
  function rewriteTitle(t) {
    return String(t)
      .replace(/\bX Premium\b/g, "Twitter Blue")
      .replace(/ \/ X$/, " / Twitter")
      .replace(/ on X:/, " on Twitter:")
      .replace(/^X$/, "Twitter");
  }

  const titleDesc = Object.getOwnPropertyDescriptor(Document.prototype, "title");
  if (titleDesc && titleDesc.set) {
    Object.defineProperty(Document.prototype, "title", {
      configurable: true,
      enumerable: true,
      get: titleDesc.get,
      set(v) { titleDesc.set.call(this, rewriteTitle(v)); },
    });
  }

  function fixTitle() {
    const cur = document.title;
    const next = rewriteTitle(cur);
    if (next !== cur) titleDesc.set.call(document, next);
  }

  new MutationObserver(fixTitle).observe(document, { subtree: true, childList: true, characterData: true });


  // ---- "X Premium" -> "Twitter Blue" ----
  const PREMIUM_RE = /\bX Premium\b/g;
  const CORP_RE = /\bX Corp\.?/g;
  const PREMIUM_ATTRS = ["aria-label", "title", "placeholder"];

  function isEditable(node) {
    const el = node.nodeType === 1 ? node : node.parentElement;
    return !el || !!el.closest('script,style,textarea,input,[contenteditable="true"],[role="textbox"]');
  }

  function fixTextNode(n) {
    const v = n.nodeValue;
    if (v && (v.indexOf("X Premium") !== -1 || v.indexOf("X Corp") !== -1) && !isEditable(n)) {
      n.nodeValue = v.replace(PREMIUM_RE, "Twitter Blue").replace(CORP_RE, "Twitter, Inc.");
    }
  }

  function fixTree(root) {
    if (!root) return;
    if (root.nodeType === 3) { fixTextNode(root); return; }
    if (root.nodeType !== 1 && root.nodeType !== 9) return;
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) fixTextNode(n);
    if (root.querySelectorAll) {
      root.querySelectorAll('[aria-label*="X Premium"],[title*="X Premium"],[placeholder*="X Premium"]').forEach((el) => {
        PREMIUM_ATTRS.forEach((a) => {
          const v = el.getAttribute(a);
          if (v && v.indexOf("X Premium") !== -1) el.setAttribute(a, v.replace(PREMIUM_RE, "Twitter Blue"));
        });
      });
    }
  }

  // The sidebar item is just labelled "Premium" (no "X"), so handle that link explicitly
  function fixNav() {
    document.querySelectorAll('a[href*="premium_sign_up"]').forEach((a) => {
      if (a.getAttribute("aria-label") === "Premium") a.setAttribute("aria-label", "Twitter Blue");
      const w = document.createTreeWalker(a, NodeFilter.SHOW_TEXT);
      let n;
      while ((n = w.nextNode())) {
        if (n.nodeValue.trim() === "Premium") n.nodeValue = n.nodeValue.replace("Premium", "Twitter Blue");
      }
    });
  }

  new MutationObserver((muts) => {
    for (const m of muts) {
      if (m.type === "characterData") fixTextNode(m.target);
      else m.addedNodes.forEach(fixTree);
    }
    fixNav();
  }).observe(document, { subtree: true, childList: true, characterData: true });

  function sweepText() { fixTree(document.body); fixNav(); }
  document.addEventListener("DOMContentLoaded", sweepText);
  window.addEventListener("load", sweepText);


  // ---- Remove Grok (sidebar link, tweet buttons, any Grok-logo icon) ----
  const GROK_PATH_PREFIX = "M12.745 20.54l10.97-8.19";
  const GROK_CSS = 'a[href^="/i/grok"], [aria-label^="Grok"] { display: none !important; }';

  function ensureGrokCss() {
    if (document.getElementById("custom-grok-css")) return;
    const parent = document.head || document.documentElement;
    if (!parent) return;
    const st = document.createElement("style");
    st.id = "custom-grok-css";
    st.textContent = GROK_CSS;
    parent.appendChild(st);
  }

  function removeGrok() {
    ensureGrokCss();
    document.querySelectorAll('svg path[d^="' + GROK_PATH_PREFIX + '"]').forEach((p) => {
      const svg = p.closest("svg");
      if (!svg) return;
      // Hide the enclosing button/link when it's just the icon; otherwise hide only the icon
      let target = svg.closest('button,a,[role="button"],[role="link"]');
      if (!target || (target.textContent || "").trim().length > 40) target = svg;
      if (target.style.display !== "none") target.style.setProperty("display", "none", "important");
    });
  }

  let grokQueued = false;
  new MutationObserver(() => {
    if (grokQueued) return;
    grokQueued = true;
    requestAnimationFrame(() => { grokQueued = false; removeGrok(); });
  }).observe(document, { subtree: true, childList: true });

  document.addEventListener("DOMContentLoaded", sweep);
  window.addEventListener("load", sweep);
  window.addEventListener("focus", sweep);
  document.addEventListener("visibilitychange", sweep);
  setInterval(sweep, 1000);
  sweep();
})();
